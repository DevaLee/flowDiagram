//
//  LGPerson.h
//  002-类方法归属分析
//
//  Created by cooci on 2020/9/12.
//  Copyright © 2020 cooci. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface LGPerson : NSObject
- (void)sayHello;
+ (void)sayHappy;

@end

NS_ASSUME_NONNULL_END
