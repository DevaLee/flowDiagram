//
//  LGTeacher.h
//  002-类方法归属分析
//
//  Created by cooci on 2020/9/14.
//  Copyright © 2020 cooci. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface LGTeacher : NSObject
- (void)say666;


@end

NS_ASSUME_NONNULL_END
