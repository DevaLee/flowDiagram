//
//  LGTeacher.m
//  002-类方法归属分析
//
//  Created by cooci on 2020/9/14.
//  Copyright © 2020 cooci. All rights reserved.
//

#import "LGTeacher.h"

@implementation LGTeacher
- (void)say666{
    
}
//+ (void)say777{
//    
//}
//// cachet_t  4 8 16
//
//+ (void)say888{
//    
//}

@end
