#include "cacheflush.h"

@implementation TestRoot (Category3)
+(int)classMethod { return 3; }
-(int)instanceMethod { return 3; }
@end
